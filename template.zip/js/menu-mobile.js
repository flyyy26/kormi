function popupMenuMobile() {
    const popupMenuMobileVar = document.getElementById("menuMobilePopup");
    popupMenuMobileVar.classList.toggle("active-menuMobilePopup");
  }